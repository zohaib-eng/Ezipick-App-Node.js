const SchoolService = require("./school.service");
const AdminService = require("./admin.service");
const ClientService = require("./client.service");
const CampusService = require("./campus.service");
const GradeService = require("./grade.service");
const TeacherService = require("./teacher.service");
const TeacherGradeService = require("./teacherGrade.service");
const StudentService = require("./student.service");
const ParentService = require("./parent.service");
const RequestService = require("./request.service");

module.exports = {
  SchoolService,
  AdminService,
  ClientService,
  CampusService,
  GradeService,
  TeacherService,
  TeacherGradeService,
  StudentService,
  ParentService,
  RequestService,
};
