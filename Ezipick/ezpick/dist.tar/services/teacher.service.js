// Package Imports

// Local Imports
const { db } = require("../database");
const { catchError } = require("../utils");

class TeacherService {
  // Get All
  static getAll = async () =>
    await catchError(async () => {
      const result = await db.Teachers.findAll({
          order: [["createdAt", "DESC"]],
          attributes: {
              exclude: ["schoolId", "clientId"],
          },
          include: [
              {
                  model: db.Grades,
                  include: [
                      { model: db.Schools},
                      { model: db.Students },
                  ],
              },
          ],
      });
      if (result) return { result };
      else throw new Error();
    });

  static getByGrade = async (gradeId) =>
    await catchError(async () => {
      const result = await db.Teachers.findAll({
          order: [["createdAt", "DESC"]],
          attributes: {
              exclude: ["schoolId", "clientId"],
          },
          include: [
              {
                  model: db.Grades,
                  include: [
                      { model: db.Schools},
                      { model: db.Students },
                  ],
              },
          ],
      });
      if (result) return { result };
      else throw new Error();
    });

  // Get By Id
  static getById = async (id) =>
    await catchError(async () => {
      const result = await db.Teachers.findByPk(id, {
          order: [["createdAt", "DESC"]],
          attributes: {
              exclude: ["schoolId", "clientId"],
          },
          include: [
              {
                  model: db.Grades,
                  include: [
                      { model: db.Schools},
                      { model: db.Students },
                  ],
              },
          ],
      });
      if (result) return { result };
      else throw new Error();
    });

  static getByColumn = async (args) =>
    await catchError(async () => {
      const result = await db.Teachers.findAll({
        where: { ...args },
        order: [["createdAt", "DESC"]],
        attributes: {
          exclude: [ "schoolId", "clientId"],
        },
        include: [
          {
            model: db.Grades,
            attributes: ["id", ["name", "grade"]],
              include: [
                  { model: db.Schools, attributes: ["id", ["name", "school"]] },
                  { model: db.Students },
              ],
          },
        ],
      });
      if (result) return { result };
      else throw new Error();
    });

  // Create
  static create = async (data) =>
    await catchError(async () => {
      const result = await db.Teachers.create(data);
        await TeacherService.update(result.id, { userName: result.id })
      return { result };
    });

  // Update
  static update = async (id, data) =>
    await catchError(async () => {
      const affectedRows = await db.Teachers.update(data, { where: { id } });
      if (affectedRows == 1) return { result: true };
      else throw new Error();
    });

  // Delete
  static delete = async (id) =>
    await catchError(async () => {
      const affectedRows = await db.Teachers.destroy({ where: { id } });
      if (affectedRows == 1) return { result: true };
      else throw new Error();
    });
};
module.exports = TeacherService
