// Package Imports

// Local Imports
const { db } = require("../database");
const { catchError } = require("../utils");
const { hash } = require("../utils/bcrypt");

class ParentService {
  // Get All
  static getAll = async () =>
    await catchError(async () => {
      const result = await db.Parents.findAll( {
          order: [["createdAt", "DESC"]],
          include: {model: db.Students, include: {model: db.Grades, include: db.Schools}}
      });
      if (result) return { result };
      else throw new Error();
    });

  // Get By Id
  static getById = async (id) =>
    await catchError(async () => {
      const result = await db.Parents.findByPk(id, {
          order: [["createdAt", "DESC"]],
          include: {model: db.Students, include: {model: db.Grades, include: db.Schools}}
      });
      if (result) return { result };
      else throw new Error();
    });

  static getByColumn = async (columnName, columnValue) =>
    await catchError(async () => {
      const result = await db.Parents.findAll({
        where: { [columnName]: columnValue },
        order: [["createdAt", "DESC"]],
          include: {model: db.Students, include: {model: db.Grades, include: db.Schools}}
      });
      if (result.length === 0) throw new Error();
      if (result) return { result };
      else throw new Error();
    });
  static getByColumnForLogin = async (columnName, columnValue) =>
    await catchError(async () => {
      const result = await db.Parents.findAll({
        where: { [columnName]: columnValue },
        order: [["createdAt", "DESC"]],
        include: {model: db.Students, include: {model: db.Grades, include: db.Schools}}
      });
      if (result.length === 0) throw new Error();
      if (result) return { result };
      else throw new Error();
    });
  // Create
  static create = async (data) =>
    await catchError(async () => {
      const defaultPassword = "12345678";
      const password = await hash(defaultPassword);
      const result = await db.Parents.create({ password, ...data });
      await ParentService.update(result.id, { userName: result.id })
      return { result };
    });

  // Update
  static update = async (id, data) =>
    await catchError(async () => {
      const affectedRows = await db.Parents.update(data, { where: { id } });
      if (affectedRows == 1) return { result: true };
      else throw new Error();
    });

  // Delete
  static delete = async (id) =>
    await catchError(async () => {
      const affectedRows = await db.Parents.destroy({ where: { id } });
      if (affectedRows == 1) return { result: true };
      else throw new Error();
    });
};

module.exports = ParentService