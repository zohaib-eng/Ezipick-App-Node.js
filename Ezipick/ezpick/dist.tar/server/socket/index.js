const { Server: SocketServer } = require("socket.io");
const jwt = require("jsonwebtoken");

const { StudentService, RequestService } = require("../../services");

module.exports.initiateSocket = (server) => {
  // Arrays to record which students and teachers are connected
  let connectedStudents = [];
  let connectedTeachers = [];

  // add student
  const addStudent = (student) => {
    let itemIndex = -1;
    const existing = connectedStudents.find((s, index) => {
      if (s.studentId === student.studentId) {
        itemIndex = index;
        return true;
      } else return false;
    });

    if (!existing) connectedStudents.push(student);
    else connectedStudents[itemIndex].socketId = student.socketId;

    return student;
  };

  // add teacher
  const addTeacher = (teacher) => {
    let itemIndex = -1;
    const existing = connectedTeachers.find((s, index) => {
      if (s.teacherId === teacher.teacherId) {
        itemIndex = index;
        return true;
      } else return false;
    });

    if (!existing) connectedTeachers.push(teacher);
    else connectedTeachers[itemIndex].socketId = teacher.socketId;

    return teacher;
  };

  // instantiate socket server
  const io = new SocketServer(server, {
    cors: {
      origin: "*",
    },
  });

  // handle on connect event
  io.sockets.on("connection", async (socket) => {
    const { auth } = socket.handshake;
    if (!auth) {
      console.log("Unauthorized User connected: ");
      socket.disconnect();
      return;
    }

    const { token, role } = auth;

    if (!token) {
      console.log("Token not found");
      socket.disconnect();
      return;
    }

    const { id } = jwt.verify(token.trim(), process.env.JWT_SECRET);
    if (!id) {
      console.log("Invalid Token: ", auth.token);
      socket.disconnect();
      return;
    }

    if (!role) {
      console.log("Invalid Role: ", role);
      socket.disconnect();
      return;
    }

    switch (role.toUpperCase()) {
      case "TEACHER": {
        teacherEvents(socket, { id }).then(() => {
          console.log("Teacher Events Attached");
        });
        break;
      }
      case "PARENT": {
        parentEvents(socket, { id }).then(() => {
          console.log("Parent Events Attached");
        });
        break;
      }
      default: {
        console.log("Invalid Role: ", role);
        socket.disconnect();
        return;
      }
    }
  });

  async function handleNewRequest({ parentId, studentId }) {
    const existing = await RequestService.getTodayRequestByParentAndStudent(
      parentId,
      studentId
    );
    if (existing) {
      const {
        result: { id: teacherId },
      } = await StudentService.getId(studentId);

      if (teacherId) {
        const connection = await connectedTeachers.find(
          (c) => c.teacherId === teacherId
        );

        if (connection) {
          const { socketId } = connection;

          io.to(socketId).emit("_new_request", existing);
        }
      }
    } else {
      const request = await RequestService.create({ parentId, studentId });
      const {
        result: { id: teacherId },
      } = await StudentService.getId(studentId);

      if (teacherId) {
        const connection = await connectedTeachers.find(
          (c) => c.teacherId === teacherId
        );

        if (connection) {
          const { socketId } = connection;

          io.to(socketId).emit("_new_request", request);
        }
      }
    }
  }

  async function handleConfirmRequest({ studentId }) {
    const { result } = await RequestService.getLatestByStudent(studentId);

    if (result) {
      await RequestService.update(result.id, { status: 2 });
    }
  }

  async function handleApproveRequest({ requestId }) {
    await RequestService.update(requestId, { status: 1 });

    const { result } = await RequestService.getById(requestId);

    // get connection for the student
    const connection = connectedStudents.find(
      (c) => c.studentId === result.studentId
    );

    if (connection) {
      console.log("Found Connection");
      io.to(connection.socketId).emit("_approved_request", {
        studentId: connection.studentId,
      });
    } else {
      console.log("Connection Not Found", result.studentId, connectedStudents);
    }
  }

  async function parentEvents(socket, { id }) {
    const { result: students } = await StudentService.getIdsByParent(id);
    if (students.length === 0) return;

    const connections = [];

    students.forEach((s) => {
      const connection = addStudent({
        studentId: s.id,
        socketId: socket.id,
      });
      connections.push(connection);
    });

    // handle on disconnect event
    socket.on("disconnect", () => {
      console.log("Parent Disconnected");

      connectedStudents = connectedStudents.filter((s) => {
        const existing = connections.find((c) => c.studentId === s.studentId);
        return !existing;
      });
    });

    const { result } = await RequestService.getTodayRequestsByParent(id);

    if (result) {
      socket.emit("_parent_requests", result);
    }

    // create request
    socket.on("_request_student", (data) => {
      handleNewRequest(data);
    });

    // create request
    socket.on("_confirm_request", (data) => {
      handleConfirmRequest(data);
    });
  }

  async function teacherEvents(socket, { id }) {
    const teacher = { teacherId: id, socketId: socket.id };

    const connection = addTeacher(teacher);

    const { result } = await RequestService.getTodayRequestsByTeacher(id);

    socket.emit("_teacher_requests", result);

    // handle on disconnect event
    socket.on("disconnect", () => {
      console.log("Teacher Disconnected");
      connectedTeachers = connectedTeachers.filter(
        (s) => s.socketId !== connection.socketId
      );
    });

    // create request
    socket.on("_approve_request", (data) => {
      handleApproveRequest(data);
    });
  }
};
