// Package Imports
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// Local Imports
const { hash } = require("../utils/bcrypt");
// Local Imports
const JWT_SECRET = process.env.JWT_SECRET || "secret";
const { TeacherService, TeacherGradeService } = require("../services");
const  nodemailer = require("nodemailer");

module.exports = class {

  // Update Password
  static async updatePassword(req, res) {
    const { id, newPassword, oldPassword } = req.body;

    const user = await TeacherService.getById(id);
    if (user.error) {
      res.status(200).json({ success: false ,message:'User not found'});
      return;
    }
    if (!newPassword && newPassword.length==0) {
      res.status(200).json({ success: false ,message:' New password filed is missing'});
      return;
    }
    if (!oldPassword && oldPassword.length==0) {
      res.status(200).json({ success: false ,message:'Old password filed is missing'});
      return;
    }
    // validate old password
    const isValidPassword = await bcrypt.compare(oldPassword, user.result.password);
    if (!isValidPassword) {
      res.status(200).json({ success: false ,message:'Invalid Existing  password'});
      return;
    }

    const hashedPassword = await hash(newPassword);

    const data = await TeacherService.update(id, {
      password: hashedPassword,
    });
    console.log(data)
    if (data.error) {
      res
          .status(500)
          .json({ success: false, message: "Request could not be processed." });
    } else {
      res.status(200).json({ success: true , message: "Password Updated successful." });
    }
  }
  //login by email
  static async loginByEmail(req, res) {
    const { email } = req.body;

    // Validate Email
    if (!email || email.trim() === "") {
      res
          .status(400)
          .json({ success: false, message: "Please provide an email." });
      return;
    }



    // Fetch user with the email
    const userCheck = await TeacherService.getByColumn({ email: email });
    if (userCheck.error) {
      res.status(200).json({
        success: false,
        message: "Looks like you haven't registered this User yet...",
      });
      return;
    }

    const [result] = userCheck.result;

    // Data to send as API response
    const response = {
      id: result.id,
      email: result.email,
      name: result.name,
    };

    // Generate JWT Token
    const token = jwt.sign(response, JWT_SECRET);

    // Final Response
    res.status(200).json({
      success: true,
      message: "Login successful",
      data: response,
      token,
    });
  }
  // forgot pasword
  static async forgotPassword(req, res) {
    const { userName } = req.params;
    if (userName) {
      const data = await TeacherService.getByColumn({userName} );
      if (data.error) {
        res.status(200).json({ success: false, message: "Not found." });
      } else {
        // check email
        const parent = data.result[0];
        if(parent.email){
          // Data to send as API parent
          const currentDate = new Date()
          const expiry = currentDate.setTime(currentDate.getTime() + (2*60*60*1000));
          const TOKEN_DATA = {
            id: parent.id,
            expiry
          };
          // Generate JWT Token
          const token = jwt.sign(TOKEN_DATA, JWT_SECRET);

          //send email

          // create reusable transporter object using the default SMTP transport
          let transporter = nodemailer.createTransport({
            host: "smtp-relay.sendinblue.com",
            port: 587,
            secure: false, // true for 465, false for other ports
            auth: {
              user: 'waqar@whetstonez.com', // generated ethereal user
              pass: 'V5LA3D92KhOfjMB1', // generated ethereal password
            },
          });

          // send mail with defined transport object
          let info = await transporter.sendMail({
            from: '"EZPick 👻" < info@ezpick.co>', // sender address
            to: "bikerztest14@gmail.com,waqargill@gmail.com", // list of receivers
            subject: "Forgot Password ✔", // Subject line
            html: `<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Forgot Password</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        font-size: 14px;
        line-height: 1.5;
        color: #333;
        margin: 0;
        padding: 0;
      }
      .container {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        background-color: #f5f5f5;
      }
      h1 {
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 20px;
      }
      p {
        margin-bottom: 10px;
      }
      a {
        color: #007bff;
        text-decoration: none;
      }
      a:hover {
        text-decoration: underline;
      }
      .footer {
        margin-top: 20px;
        text-align: center;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <h1 style="text-align:center ">Forgot Password</h1>
      <p>Hello,</p>
      <p>You have requested to reset your password for our website. Please click the link below to reset your password:</p>
      <p><a href="https://www.google.com/${token}">Reset</a></p>
      <p>If you did not request to reset your password, please ignore this email.</p>
      <div class="footer" style="text-align:left ">
        <p>Thank you,</p>
        <p>EZPick Team</p>
      </div>
    </div>
  </body>
</html>`, // html body
          });

          console.log("Message sent: %s", info.messageId);
          // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>

          // Preview only available when sending through an Ethereal account
          console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
          // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...



          // Final parent
          res.status(200).json({
            success: true,
            message: "Password Update successful",
          });
        }else {
          res
              .status(200)
              .json({ success: false, message: "Email Not Found." });
        }

      }
    } else {
      res
          .status(400)
          .json({ success: false, message: "Parent Not found" });
    }
  }


  // Login
  static async login(req, res) {
    const { username, email, password } = req.body;

    // Validate Email
    // if (!email || email.trim() === "") {
    //   res
    //       .status(400)
    //       .json({ success: false, message: "Please provide an email." });
    //   return;
    // }
// Validate username
    if (!username || username.trim() === "") {
      res
          .status(400)
          .json({ success: false, message: "Please provide an username." });
      return;
    }

    // Validate Password
    if (!password || password.trim() === "") {
      res
          .status(400)
          .json({ success: false, message: "Please provide an password." });
      return;
    }

    // Fetch user with the email
    const userCheck = await TeacherService.getByColumn({username});
    if (userCheck.error) {
      res.status(200).json({
        success: false,
        message: "Looks like you haven't registered this username yet...",
      });
      return;
    }

    const [result] = userCheck.result;

    // Compare the passwords
    const isPasswordCorrect = await bcrypt.compare(password, result.password);
    if (!isPasswordCorrect) {
      res.status(401).json({
        success: false,
        message: "Invalid Credentials",
      });
      return;
    }

    // Data to send as API response
    const response = {
      id: result.id,
      email: result.email,
      name: result.name,
    };

    // Generate JWT Token
    const token = jwt.sign(response, JWT_SECRET);

    // Final Response
    res.status(200).json({
      success: true,
      message: "Login successful",
      data: result,
      token,
    });
  }

  // Get All
  static async getAll(_, res) {
    const data = await TeacherService.getAll();
    if (data.error) {
      res.status(500).json({ success: false, message: "Request could not be processed." });
    } else {
      res.status(200).json({ success: true, teachers: data.result });
    }
  }
// Get By Id
  static async getByClient(req, res) {
    const { id } = req.params;

    if (id) {
      const data = await TeacherService.getByColumn({ clientId: id });
      if (data.error) {
        res.status(200).json({ success: true, teachers: [] });
      } else {
        res.status(200).json({ success: true, teachers: data.result });
      }
    } else {
      res.status(400).json({ success: false, message: "Please provide client ID." });
    }
  }
  // Get By teacher id
  static async getByGradeId(req, res) {
    const { id } = req.params;


    if (id) {
      const data = await TeacherService.getByGrade(id);
      if (data.error) {
        res.status(200).json({ success: true, teachers: [] });
      } else {
        res.status(200).json({ success: true, teachers: data.result });
      }
    } else {
      res.status(400).json({ success: false, message: "Please provide school ID." });
    }
  }
  static async getBySchoolId(req, res) {
    const { id } = req.params;

    if (id) {
      const data = await TeacherService.getByColumn({ schoolId: id });
      if (data.error) {
        res.status(200).json({ success: true, teachers: [] });
      } else {
        res.status(200).json({ success: true, teachers: data.result });
      }
    } else {
      res.status(400).json({ success: false, message: "Please provide school ID." });
    }
  }

  // Get By Id
  static async getById(req, res) {
    const { id } = req.params;

    if (id) {
      const data = await TeacherService.getById(id);
      if (data.error) {
        res.status(200).json({ success: false, message: "Not found." });
      } else {
        res.status(200).json({ success: true, teacher: data.result });
      }
    } else {
      res.status(400).json({ success: false, message: "Please provide an ID." });
    }
  }

  // Create
  static async create(req, res) {
    const { email, password, ...rest } = req.body;
    if (!email) {
      res
          .status(200)
          .json({ success: false, message: "Please provide an email." });
      return;
    }
    const existingUserCheck = await TeacherService.getByColumn({ email });
    if (existingUserCheck.result.length > 0) {
      res.status(200).json({ success: false, message: "Email Already Registered." })
      return;
    }
    const hashedPassword = await hash(password);
    const data = await TeacherService.create({ password: hashedPassword,
      email,
      ...rest,
    });
    if (data.error) {
      res.status(500).json({ success: false, message: "Request could not be processed." });
    } else {

      const teacherId = data.result.id;
      //
      // for (let i in req.body.grades) {
      //   const gradeId = req.body.grades[i];
      //   await TeacherGradeService.create({ teacherId, gradeId });
      // }

      const { result } = await TeacherService.getById(teacherId);

      res.status(200).json({ success: true, teacher: result });
    }
  }

  // Update
  static async update(req, res) {
    const { id, ...rest } = req.body;

    if (id) {
      const data = await TeacherService.update(id, { ...rest });
      if (data.error) {
        res.status(500).json({
          success: false,
          message: "Request could not be processed.",
        });
      } else {
        res.status(200).json({ success: true });
      }
    } else {
      res.status(400).json({ success: false, message: "Please provide an ID." });
    }
  }

  // Delete
  static async delete(req, res) {
    const { id } = req.params;

    if (id) {
      const data = await TeacherService.delete(id);
      if (data.error) {
        res.status(500).json({
          success: false,
          message: "Request could not be processed.",
        });
      } else {
        res.status(200).json({ success: true });
      }
    } else {
      res.status(400).json({ success: false, message: "Please provide an ID" });
    }
  }
};
