// Package Imports

// Local Imports
const { StudentService, ParentService } = require("../services");

module.exports = class {
  // Get All
  static async getAll(_, res) {
    const data = await StudentService.getAll();
    if (data.error) {
      res
        .status(500)
        .json({ success: false, message: "Request could not be processed." });
    } else {
      res.status(200).json({ success: true, students: data.result });
    }
  }
  // Get By Id
  static async getByClient(req, res) {
    const { id } = req.params;

    if (id) {
      const data = await StudentService.getByColumn("clientId", id);
      if (data.error) {
        res.status(200).json({ success: true, students: [] });
      } else {
        res.status(200).json({ success: true, students: data.result });
      }
    } else {
      res
        .status(200)
        .json({ success: false, message: "Please provide client ID." });
    }
  }
  static async getByParent(req, res) {
    const { id } = req.params;

    if (id) {
      const data = await StudentService.getByColumn("parentId", id);
      if (data.error) {
        res.status(200).json({ success: true, students: [] });
      } else {
        res.status(200).json({ success: true, students: data.result });
      }
    } else {
      res
        .status(200)
        .json({ success: false, message: "Please provide client ID." });
    }
  }
  // Get By Id
  static async getById(req, res) {
    const { id } = req.params;

    if (id) {
      const data = await StudentService.getById(id);
      if (data.error) {
        res.status(200).json({ success: false, message: "Not found." });
      } else {
        res.status(200).json({ success: true, student: data.result });
      }
    } else {
      res
        .status(200)
        .json({ success: false, message: "Please provide an ID." });
    }
  }
  // Get teacherId
  static async getTeacherId(req, res) {
    const { id } = req.params;

    if (id) {
      const data = await StudentService.getId(id);
      if (data.error) {
        res.status(200).json({ success: false, message: "Not found." });
      } else {
        res.status(200).json({ success: true, teacherId: data.result });
      }
    } else {
      res
        .status(200)
        .json({ success: false, message: "Please provide an ID." });
    }
  }

  // Create
  static async create(req, res) {
    // first search the parent based on the email and phone no
    const { parentEmail, parentPhoneNo, parentId: parentIdFromReq } = req.body;

    let parentId = undefined;

    if (!parentIdFromReq) {
      if (!parentEmail) {
        res.status(400).json({
          success: false,
          message: "Please provide parent email.",
        });
        return;
      }

      const existingParentCheck = await ParentService.getByColumn(
        "email",
        parentEmail
      );

      if (!existingParentCheck.error) {
        parentId = existingParentCheck.result[0].id;
      } else {
        const newParent = {
          email: parentEmail,
        };
  
        if (parentPhoneNo) newParent.phoneNo = parentPhoneNo;
  
        const parentAddition = await ParentService.create(newParent);
        if (parentAddition.error) {
          res.status(500).json({
            success: false,
            message: "Request could not be processed.",
          });
          return;
        }
        parentId = parentAddition.result.id;
      }
    } else {
      parentId = parentIdFromReq;
    }
    
    const data = await StudentService.create({ ...req.body, parentId });
    if (data.error) {
      res
        .status(500)
        .json({ success: false, message: "Request could not be processed." });
    } else {
      const { result } = await StudentService.getById(data.result.id)
      res.status(200).json({ success: true, student: result });
    }
  }

  // Update
  static async update(req, res) {
    const { id,parentEmail, ...rest } = req.body;
    if(parentEmail){

      const existingParentCheck = await ParentService.getByColumn(
          "email",
          parentEmail
      );
      if (existingParentCheck.error) {
        res.status(500).json({
          success: false,
          message: "Request could not be processed dfdfd.",
        });
      } else {
        if(existingParentCheck.result[0].email){
          res.status(500).json({
            success: true,
            message: "This email is already exits Leave Email filed empty.",
          });
          return;
        }
      }

    }
    if (id) {
      const data = await StudentService.update(id, { ...rest });
      if (data.error) {
        res.status(500).json({
          success: false,
          message: "Request could not be processed.",
        });
      } else {
        res.status(200).json({ success: true });
      }
    } else {
      res
        .status(400)
        .json({ success: false, message: "Please provide an ID." });
    }
  }

  // Delete
  static async delete(req, res) {
    const { id } = req.params;

    if (id) {
      const data = await StudentService.delete(id);
      if (data.error) {
        res.status(500).json({
          success: false,
          message: "Request could not be processed.",
        });
      } else {
        res.status(200).json({ success: true });
      }
    } else {
      res.status(400).json({ success: false, message: "Please provide an ID" });
    }
  }
};
