const { DataTypes } = require("sequelize");

module.exports = (db) => {
  return db.define(
    "parents",
    {
      id: {
        type: DataTypes.BIGINT,
        primaryKey: true,
        autoIncrement: true,
      },
      name: {
        type: DataTypes.TEXT,
      },
      email: {
        allowNull: false,
        type: DataTypes.TEXT,
      },
        userName: {
        type: DataTypes.TEXT,
      },
      phoneNo: {
        type: DataTypes.TEXT,
      },
      password: {
        allowNull: false,
        type: DataTypes.TEXT,
      },
    },
    {
      initialAutoIncrement: 1000000,
    }
  );
};
