// Package Imports
const Sequelize = require("sequelize");

// Local Imports
const dbConfig = require("./db.config");
const {
  getSchoolModel,
  getAdminModel,
  getClientModel,
  // getCampusModel,
  getGradeModel,
  getTeacherModel,
  getTeacherGradeModel,
  getStudentModel,
  getParentModel,
  getRequestModel,
} = require("./models");

const defineRelations = (db) => {
  // Relations for Clients
  db.Clients.hasMany(db.Schools);

  // Relations for Schools
  db.Schools.belongsTo(db.Clients);
  db.Schools.hasMany(db.Grades);
  db.Schools.hasMany(db.Teachers);


  // Relations for Grades
  db.Grades.belongsTo(db.Schools);
  db.Grades.belongsTo(db.Teachers);
  db.Grades.hasMany(db.Students);

  // Relations for Teachers
  db.Teachers.hasMany(db.Students);
  db.Teachers.hasMany(db.Grades);
  db.Teachers.belongsTo(db.Schools);

  // Relations for Parents
  db.Parents.hasMany(db.Students);

  // Relations for Students
  db.Students.belongsTo(db.Grades);
  db.Students.belongsTo(db.Teachers);
  db.Students.belongsTo(db.Parents);

  // Relations for Request
  db.Students.hasMany(db.Requests);

  db.Requests.belongsTo(db.Students);

};

class Database {
  static db = {};
  static connect() {
    const sequelize = new Sequelize(
      dbConfig.DB,
      dbConfig.USER,
      dbConfig.PASSWORD,
      {
        host: dbConfig.HOST,
        dialect: dbConfig.dialect,
        operatorsAliases: false,

        pool: { ...dbConfig.pool },
      }
    );

    const { db } = Database;

    db.Sequelize = Sequelize;
    db.sequelize = sequelize;

    db.Schools = getSchoolModel(sequelize);
    db.Admins = getAdminModel(sequelize);
    db.Clients = getClientModel(sequelize);
    // db.Campuses = getCampusModel(sequelize);
    db.Grades = getGradeModel(sequelize);
    db.Teachers = getTeacherModel(sequelize);
    // db.TeachersGrades = getTeacherGradeModel(sequelize);
    db.Students = getStudentModel(sequelize);
    db.Parents = getParentModel(sequelize);
    db.Requests = getRequestModel(sequelize);

    // define relations
    defineRelations(db);

    db.sequelize
      .sync()
      .then(() => {
        console.log("Synced db.");
      })
      .catch((err) => {
        console.log("Failed to sync db: " + err.message);
      });
  }
}

module.exports = Database;
