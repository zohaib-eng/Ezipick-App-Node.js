const { ParentController } = require("../controllers");

const express = require("express");
const router = express.Router();

router.get("/", ParentController.getAll);
router.get("/:id", ParentController.getById);
router.get("/hasEmail/:userName", ParentController.hasEmail);
router.put("/create", ParentController.create);
router.patch("/update", ParentController.update);
router.delete("/:id", ParentController.delete);

router.post("/loginByUsername", ParentController.loginByUsername);
router.post("/loginByEmail", ParentController.loginByEmail);
router.patch("/update-password", ParentController.updatePassword);
router.get("/forgot-password/:userName", ParentController.forgotPassword);

module.exports = router;
