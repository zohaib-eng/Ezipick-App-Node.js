const { StudentController } = require("../controllers");

const express = require("express");
const router = express.Router();

router.get("/", StudentController.getAll);
router.get("/:id", StudentController.getById);
router.get("/getTeacherId/:id", StudentController.getTeacherId);
router.get("/client/:id", StudentController.getByClient);
router.get("/parent/:id", StudentController.getByParent);
router.put("/create", StudentController.create);
router.patch("/update", StudentController.update);
router.delete("/:id", StudentController.delete);

module.exports = router;
