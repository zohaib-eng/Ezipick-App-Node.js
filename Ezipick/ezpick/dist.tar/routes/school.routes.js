const { SchoolController } = require("../controllers");

const express = require("express");
const router = express.Router();

router.get("/", SchoolController.getAll);
router.get("/client/:id", SchoolController.getByClient);
router.get("/:id", SchoolController.getById);
router.put("/create", SchoolController.create);
router.patch("/update", SchoolController.update);
router.delete("/:id", SchoolController.delete);

module.exports = router;
