const { GradeController } = require("../controllers");

const express = require("express");
const router = express.Router();

router.get("/", GradeController.getAll);
router.get("/:id", GradeController.getById);
router.get("/client/:id", GradeController.getByClient);
router.get("/school/:id", GradeController.getBySchool);
router.get("/teacher/:id", GradeController.getByTeacher);
router.put("/create", GradeController.create);
router.patch("/update", GradeController.update);
router.delete("/:id", GradeController.delete);

module.exports = router;
