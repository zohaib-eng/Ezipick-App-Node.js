const { TeacherController } = require("../controllers");

const express = require("express");
const router = express.Router();

router.get("/", TeacherController.getAll);
router.get("/:id", TeacherController.getById);
router.get("/client/:id", TeacherController.getByClient);
router.get("/grade/:id", TeacherController.getByGradeId);
router.get("/school/:id", TeacherController.getBySchoolId);
router.put("/create", TeacherController.create);
router.patch("/update", TeacherController.update);
router.delete("/:id", TeacherController.delete);

// ** Auth Routes
router.post("/loginByUsername", TeacherController.login);
router.patch("/update-password", TeacherController.updatePassword);

router.post("/loginByEmail", TeacherController.loginByEmail);
router.get("/forgot-password/:userName", TeacherController.forgotPassword);


module.exports = router;
