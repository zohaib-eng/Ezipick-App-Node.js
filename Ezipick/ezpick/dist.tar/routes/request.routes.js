const { RequestController } = require("../controllers");

const express = require("express");
const router = express.Router();

router.get("/", RequestController.getAll);
router.get("/client/:id", RequestController.getByClient);
router.get("/student/:id", RequestController.getByStudent);
// router.get("/parent/:id", RequestController.getByParent);
router.get("/parent/:id", RequestController.getAllWithDates);
router.get("/grade/:id", RequestController.getAllByGrades);
router.get("/:id", RequestController.getById);
router.put("/create", RequestController.create);
router.patch("/update", RequestController.update);
router.delete("/:id", RequestController.delete);

module.exports = router;
